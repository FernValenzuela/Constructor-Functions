# Instructions  

1. Create a constructor function called `NewRepublicHolidayHotels.`
2. Have it take in `data` as a parameter.
3. Assign the data to `this`.
4. Log out the result of creating an instance of `NewRepublicHolidayHotels` for each hotel.
  